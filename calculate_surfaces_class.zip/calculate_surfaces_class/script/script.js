"use strict";
function calculateSurface(shape) {
    let area = 0;
    let perimeter = 0;
    switch (shape.type) {
        case "rectangle":
            if (shape.width) {
                area = shape.length * shape.width;
                perimeter = 2 * (shape.length + shape.width);
            }
            break;
        case "square":
            area = shape.length * shape.length;
            perimeter = 4 * shape.length;
            break;
        case "circle":
            area = Math.PI * Math.pow(shape.length, 2);
            perimeter = 2 * Math.PI * shape.length;
            break;
        default:
            throw new Error("invalid shape selected");
    }
    return { area, perimeter };
}
function drawShape(shape) {
    const canvas = document.getElementById("shapeCanvas"); // type assertion: "dit element is vanaf nu eigenlijk iets anders"
    const ctx = canvas.getContext('2d'); // check p5 voor canvas toepassingen
    if (!ctx)
        return; // bij fout (geen context) afhandelen
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.strokeStyle = "#000";
    ctx.lineWidth = 2;
    switch (shape.type) {
        case "rectangle":
            if (shape.width) {
                ctx.strokeRect(50, 50, shape.width, shape.length);
            }
            break;
        case "square":
            ctx.strokeRect(50, 50, shape.length, shape.length);
            break;
        case "circle":
            ctx.beginPath();
            ctx.arc(50 + shape.length, 50 + shape.length, shape.length, 0, Math.PI * 2);
            ctx.stroke();
            break;
        default:
            throw new Error("invalid shape selected");
    }
}
const form = document.getElementById("shapeForm");
form.addEventListener("submit", (e) => {
    e.preventDefault(); // we houden refresh pagina tegen
    const lengthElement = document.getElementById('length');
    const shapeElement = document.getElementById("shape");
    const widthElement = document.getElementById("width");
    const areaOutputElement = document.getElementById("area");
    const areaPerimeterElement = document.getElementById("perimeter");
    const shape = (shapeElement.value);
    const length = parseFloat(lengthElement.value);
    const width = parseFloat(widthElement.value);
    const shapeObject = {
        type: shape,
        width: width,
        length: length
    };
    const { area, perimeter } = calculateSurface(shapeObject);
    areaOutputElement.innerText = area.toString();
    areaPerimeterElement.innerText = perimeter.toString();
    drawShape(shapeObject);
});
const shapeSelectElement = document.getElementById("shape");
shapeSelectElement.addEventListener("change", (e) => {
    const widthElement = document.getElementById("width");
    const widthLabelElement = document.querySelector("label[for='width']");
    const shape = e.target.value;
    if (shape === "rectangle") {
        widthElement.style.display = "block";
        widthLabelElement.style.display = "block";
    }
    else {
        widthElement.style.display = "none";
        widthLabelElement.style.display = "none";
    }
});
