type Shape = {
    type: "rectangle" | "square" | "circle";
    length: number;
    width?: number;
}

type CalculationResult = {
    area: number;
    perimeter: number;
}

function calculateSurface(shape: Shape): CalculationResult {
    let area: number = 0;
    let perimeter: number = 0;

    switch(shape.type){
        case "rectangle":
            if (shape.width) {
            area = shape.length * shape.width;
            perimeter = 2 * (shape.length + shape.width);
            }
            break;
        case "square":
            area = shape.length * shape.length;
            perimeter = 4 * shape.length;
            break;
        case "circle":
            area = Math.PI * Math.pow(shape.length, 2);
            perimeter = 2 * Math.PI * shape.length;
            break;
        default:
            throw new Error("invalid shape selected");
    }
    return { area, perimeter }
}

function drawShape(shape: Shape) {
    const canvas = document.getElementById("shapeCanvas") as HTMLCanvasElement; // type assertion: "dit element is vanaf nu eigenlijk iets anders"
    const ctx = canvas.getContext('2d'); // check p5 voor canvas toepassingen

    if(!ctx) return; // bij fout (geen context) afhandelen

    ctx.clearRect(0,0,canvas.width, canvas.height);
    
    ctx.strokeStyle = "#000";

    ctx.lineWidth = 2;

    switch(shape.type) {
        case "rectangle":
            if(shape.width) {
                ctx.strokeRect(50, 50, shape.width, shape.length);
            }
            break;
        case "square":
            ctx.strokeRect(50, 50, shape.length, shape.length);
            break;
        case "circle":
            ctx.beginPath();
            ctx.arc(50 + shape.length, 50 + shape.length, shape.length, 0, Math.PI * 2);
            ctx.stroke();
            break;
        default:
            throw new Error("invalid shape selected");
    }
}

const form = document.getElementById("shapeForm") as HTMLFormElement;

form.addEventListener("submit", (e: Event)=> {
    e.preventDefault(); // we houden refresh pagina tegen
    const lengthElement = document.getElementById('length') as HTMLInputElement;
    const shapeElement = document.getElementById("shape") as HTMLSelectElement;
    const widthElement = document.getElementById("width") as HTMLSelectElement;
    const areaOutputElement = document.getElementById("area");
    const areaPerimeterElement = document.getElementById("perimeter");
    const shape = (shapeElement.value);
    const length = parseFloat(lengthElement.value);
    const width = parseFloat(widthElement.value);

    const shapeObject: Shape = {
        type: shape as "rectangle" | "square" | "circle",
        width: width, 
        length: length
    }

    const {area, perimeter} = calculateSurface(shapeObject);

    areaOutputElement.innerText = area.toString();
    areaPerimeterElement.innerText = perimeter.toString();

    drawShape(shapeObject);
})

const shapeSelectElement = document.getElementById("shape") as HTMLSelectElement;

shapeSelectElement.addEventListener("change", (e: Event) => {
    const widthElement = document.getElementById("width") as HTMLInputElement;
    const widthLabelElement = document.querySelector("label[for='width']") as HTMLLabelElement;
    const shape = (e.target as HTMLSelectElement).value;

    if (shape === "rectangle") {
        widthElement.style.display = "block";
        widthLabelElement.style.display = "block";
    } else {
        widthElement.style.display = "none";
        widthLabelElement.style.display = "none";
    }
});