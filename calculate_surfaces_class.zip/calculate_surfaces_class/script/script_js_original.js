// Functie om het oppervlak en de omtrek van een gegeven vorm te berekenen
function calculateSurface(shape) {
    let area = 0;
    let perimeter = 0;

    // Bepaal het type vorm en bereken dienovereenkomstig het oppervlak en de omtrek
    switch(shape.type){
        case "rectangle":
            if (shape.width) {
                area = shape.length * shape.width;
                perimeter = 2 * (shape.length + shape.width);
            }
            break;
        case "square":
            area = shape.length * shape.length;
            perimeter = 4 * shape.length;
            break;
        case "circle":
            area = Math.PI * Math.pow(shape.length, 2);
            perimeter = 2 * Math.PI * shape.length;
            break;
        default:
            throw new Error("ongeldige vorm geselecteerd");
    }
    return { area, perimeter }
}

// Functie om de vorm op een canvas te tekenen
function drawShape(shape) {
    const canvas = document.getElementById("shapeCanvas");
    const ctx = canvas.getContext('2d');

    if(!ctx) return;

    // Maak het canvas leeg voordat je gaat tekenen
    ctx.clearRect(0,0,canvas.width, canvas.height); // 0,0 is top left corner (x en y)
    
    ctx.strokeStyle = "#000";
    ctx.lineWidth = 2;

    // Teken de vorm op basis van het type
    switch(shape.type) {
        case "rectangle":
            if(shape.width) {
                ctx.strokeRect(50, 50, shape.width, shape.length);
            }
            break;
        case "square":
            ctx.strokeRect(50, 50, shape.length, shape.length);
            break;
        case "circle":
            ctx.beginPath();
            ctx.arc(50 + shape.length, 50 + shape.length, shape.length, 0, Math.PI * 2);
            /* Draws an arc (part of a circle) on the canvas context 'ctx'.
            The arc is centered at (50 + shape.length, 50 + shape.length) with a radius of 'shape.length'.
            The arc starts at angle 0 and ends at angle 2 * Math.PI (a full circle).*/
            ctx.stroke();
            break;
        default:
            throw new Error("ongeldige vorm geselecteerd");
    }
}

// Haal het formulier element op
const form = document.getElementById("shapeForm");

// Voeg een event listener toe om het formulier in te dienen
form.addEventListener("submit", (e) => {
    e.preventDefault();
    const lengthElement = document.getElementById('length');
    const shapeElement = document.getElementById("shape");
    const widthElement = document.getElementById("width");
    const areaOutputElement = document.getElementById("area");
    const areaPerimeterElement = document.getElementById("perimeter");
    const shape = shapeElement.value;
    const length = parseFloat(lengthElement.value);
    const width = parseFloat(widthElement.value);

    // Maak een vorm object met de invoerwaarden
    const shapeObject = {
        type: shape,
        width: width, 
        length: length
    }

    // Bereken het oppervlak en de omtrek van de vorm
    const {area, perimeter} = calculateSurface(shapeObject);

    // Toon het berekende oppervlak en de omtrek
    areaOutputElement.innerText = area.toString();
    areaPerimeterElement.innerText = perimeter.toString();

    // Teken de vorm op het canvas
    drawShape(shapeObject);
})

// Haal het vorm select element op
const shapeSelectElement = document.getElementById("shape");

// Voeg een event listener toe om de vorm selectie te wijzigen
shapeSelectElement.addEventListener("change", (e) => {
    const widthElement = document.getElementById("width");
    const widthLabelElement = document.querySelector("label[for='width']");
    const shape = e.target.value;

    // Toon of verberg de breedte invoer op basis van de geselecteerde vorm
    if (shape === "rectangle") {
        widthElement.style.display = "block";
        widthLabelElement.style.display = "block";
    } else {
        widthElement.style.display = "none";
        widthLabelElement.style.display = "none";
    }
});
